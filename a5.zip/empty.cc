#include "empty.h"

Empty::Empty(char piece): piece{piece}{}

Empty::~Empty() {}
