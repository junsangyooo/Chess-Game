#include "rook.h"

Rook::Rook(char piece): piece{piece} {}

Rook::~Rook() {}
