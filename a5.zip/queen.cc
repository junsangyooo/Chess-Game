#include "queen.h"

Queen::Queen(char piece): piece{piece} {}

Queen::~Queen() {}
