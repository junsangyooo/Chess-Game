#include "computer.h"

Computer::~Computer() {}
