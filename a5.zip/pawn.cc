#include "pawn.h"

Pawn::Pawn(char piece): piece{piece}{}

Pawn::~Pawn() {}
