#include "knight.h"

Knight::Knight(char piece): piece{piece}{}

Knight::~Knight() {}
