#include "king.h"

King::King(char piece): piece{piece}{}

King::~King() {}
